/**
 * @name SelectiveMediaSaver
 * @version 2.4.0
 * @description Saves received image/video files from selected Discord users, servers, or channels. Includes folders, dedupe, cleanup, avatars, passive banner tracking, and manual message saving.
 * @author ChatGPT
 */

module.exports = class SelectiveMediaSaver {
  getName() { return "SelectiveMediaSaver"; }
  getVersion() { return "2.4.0"; }
  getAuthor() { return "ChatGPT"; }
  getDescription() {
    return "Saves received image/video files from selected users, servers, or channels.";
  }

  start() {
    this.fs = require("fs");
    this.path = require("path");
    this.crypto = require("crypto");

    this.pluginDir = BdApi.Plugins.folder;
    this.baseDir = this.path.join(this.pluginDir, "SelectiveMediaSaver");
    this.avatarsDir = this.path.join(this.baseDir, "Avatars");
    this.bannersDir = this.path.join(this.baseDir, "Banners");
    this.metadataPath = this.path.join(this.baseDir, "metadata.json");
    this.hashIndexPath = this.path.join(this.baseDir, "hash_index.json");

    this.mediaExtensions = {
      images: [".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif", ".apng"],
      videos: [".mp4", ".mov", ".webm", ".mkv", ".m4v"]
    };

    this.defaultSettings = {
      enabled: true,
      onlySaveAllowlisted: true,
      matchAnyAllowlist: true,

      allowedUserIds: [],
      allowedGuildIds: [],
      allowedChannelIds: [],

      ignoreBots: true,
      ignoreSelf: true,

      saveImages: true,
      saveVideos: true,
      saveAvatarsForAllowlistedUsers: false,
      saveBannersForAllowlistedUsers: false,

      trackAvatarChanges: true,
      trackBannerChanges: true,
      avatarCheckIntervalMinutes: 10,
      bannerCheckIntervalMinutes: 15,

      avatarHistory: {},
      bannerHistory: {},

      folderMode: "smart",
      duplicateMode: "skip",

      showToastOnSave: true,
      saveMetadata: true,
      debugMode: true,
      contextMenuToggles: true,

      autoCleanupEnabled: false,
      maxTotalSizeGB: 5,
      deleteOlderThanDays: 0
    };

    this.settings = Object.assign(
      {},
      this.defaultSettings,
      BdApi.Data.load(this.getName(), "settings") || {}
    );

    this.ensureFolders();

    this.hashIndex = this.loadJson(this.hashIndexPath, {});
    this.metadataCache = this.loadJson(this.metadataPath, []);

    this.UserStore = this.getStore("UserStore") || BdApi.Webpack.getByKeys("getCurrentUser", "getUser");
    this.ChannelStore = this.getStore("ChannelStore") || BdApi.Webpack.getByKeys("getChannel", "hasChannel");
    this.GuildStore = this.getStore("GuildStore") || BdApi.Webpack.getByKeys("getGuild", "getGuildCount");
    this.SelectedChannelStore = this.getStore("SelectedChannelStore");
    this.SelectedGuildStore = this.getStore("SelectedGuildStore");
    this.MessageStore = this.getStore("MessageStore") || BdApi.Webpack.Stores?.MessageStore;
    this.UserProfileStore = this.getStore("UserProfileStore") || BdApi.Webpack.getByKeys("getUserProfile", "getMutableUserProfile");

    this.localUser = this.UserStore?.getCurrentUser?.();
    this.seenKeys = new Set();

    this.patchMessageListener();
    this.patchUserUpdateListener();
    this.patchUserProfileListener();
    if (this.settings.contextMenuToggles) this.patchContextMenus();

    this.startAvatarWatcher();
    this.startBannerWatcher();

    this.cleanupInterval = setInterval(() => this.runCleanupSafe(), 1000 * 60 * 30);
    this.runCleanupSafe();

    BdApi.UI.showToast("SelectiveMediaSaver 2.4.0 started.", { type: "success" });
    this.debug("Started. Saving to:", this.baseDir);
  }

  stop() {
    if (this.unsubscribeMessageCreate) {
      try { this.unsubscribeMessageCreate(); } catch {}
      this.unsubscribeMessageCreate = null;
    }

    if (this.unsubscribeUserUpdate) {
      try { this.unsubscribeUserUpdate(); } catch {}
      this.unsubscribeUserUpdate = null;
    }

    if (this.unsubscribeUserProfileFetch) {
      try { this.unsubscribeUserProfileFetch(); } catch {}
      this.unsubscribeUserProfileFetch = null;
    }

    if (this.avatarWatcherInterval) {
      clearInterval(this.avatarWatcherInterval);
      this.avatarWatcherInterval = null;
    }

    if (this.bannerWatcherInterval) {
      clearInterval(this.bannerWatcherInterval);
      this.bannerWatcherInterval = null;
    }

    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }

    BdApi.Patcher.unpatchAll(this.getName());

    if (this.contextMenuUnpatches) {
      for (const unpatch of this.contextMenuUnpatches) {
        try { unpatch(); } catch {}
      }
      this.contextMenuUnpatches = [];
    }

    BdApi.UI.showToast("SelectiveMediaSaver stopped.", { type: "info" });
  }

  getStore(name) {
    try {
      return BdApi.Webpack.getStore?.(name) || BdApi.Webpack.Stores?.[name] || null;
    } catch {
      return null;
    }
  }

  debug(...args) {
    if (this.settings?.debugMode) console.log("[SelectiveMediaSaver]", ...args);
  }

  ensureFolders() {
    for (const dir of [this.baseDir, this.avatarsDir, this.bannersDir]) {
      if (!this.fs.existsSync(dir)) this.fs.mkdirSync(dir, { recursive: true });
    }
  }

  loadJson(file, fallback) {
    try {
      if (!this.fs.existsSync(file)) return fallback;
      const raw = this.fs.readFileSync(file, "utf8");
      return raw.trim() ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  saveJson(file, data) {
    this.fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
  }

  saveSettings() {
    BdApi.Data.save(this.getName(), "settings", this.settings);
  }

  patchMessageListener() {
    const dispatcher =
      BdApi.Webpack.getByKeys("subscribe", "unsubscribe", "dispatch") ||
      BdApi.Webpack.getByKeys("_dispatcher")?._dispatcher ||
      BdApi.Webpack.getByKeys("dirtyDispatch", "dispatch");

    this.dispatcher = dispatcher;

    const onMessageCreate = event => {
      try {
        this.handleMessageCreateEvent(event);
      } catch (err) {
        console.error("[SelectiveMediaSaver] MESSAGE_CREATE handler error:", err);
      }
    };

    if (dispatcher?.subscribe && dispatcher?.unsubscribe) {
      try {
        dispatcher.subscribe("MESSAGE_CREATE", onMessageCreate);
        this.unsubscribeMessageCreate = () => dispatcher.unsubscribe("MESSAGE_CREATE", onMessageCreate);
        this.debug("Subscribed to MESSAGE_CREATE.");
      } catch (err) {
        console.warn("[SelectiveMediaSaver] Could not subscribe to MESSAGE_CREATE:", err);
      }
    }

    if (dispatcher?.dispatch) {
      try {
        BdApi.Patcher.after(this.getName(), dispatcher, "dispatch", (_, args) => {
          const event = args?.[0];
          if (event?.type === "MESSAGE_CREATE") onMessageCreate(event);
        });
        this.debug("Patched dispatcher.dispatch fallback.");
      } catch (err) {
        console.warn("[SelectiveMediaSaver] Could not patch dispatcher fallback:", err);
      }
    }
  }

  handleMessageCreateEvent(event) {
    if (!event || event.type !== "MESSAGE_CREATE") return;
    const message = event.message || event.optimisticMessage || event.messages?.[0] || event;
    if (!message || !message.id) return;

    this.debug("Saw MESSAGE_CREATE", {
      id: message.id,
      channel_id: message.channel_id,
      guild_id: message.guild_id,
      author: message.author?.id,
      attachments: message.attachments?.length || 0,
      embeds: message.embeds?.length || 0
    });

    this.handleMessage(message, { manual: false });
  }

  async handleMessage(message, options = {}) {
    if (!this.settings.enabled && !options.manual) return;
    if (!message || !message.id) return;

    if (!options.manual) {
      if (this.settings.ignoreBots && message.author?.bot) return;
      if (this.settings.ignoreSelf && this.localUser?.id && message.author?.id === this.localUser.id) return;
      if (!this.isMessageAllowed(message)) return;
    }

    if (this.settings.saveAvatarsForAllowlistedUsers && this.isAllowedId("allowedUserIds", message.author?.id)) {
      this.checkAndSaveAvatar(message.author, "message").catch(err => console.warn("[SelectiveMediaSaver] Avatar save failed:", err));
    }

    if (this.settings.saveBannersForAllowlistedUsers && this.isAllowedId("allowedUserIds", message.author?.id)) {
      const profile = this.getCachedProfile(message.author.id);
      if (profile) {
        this.checkAndSaveBannerFromProfile(profile, message.author, "message").catch(err => console.warn("[SelectiveMediaSaver] Banner save failed:", err));
      }
    }

    const mediaItems = this.extractMedia(message);

    if (!mediaItems.length) {
      if (options.manual) BdApi.UI.showToast("No image/video media found on that message.", { type: "info" });
      return;
    }

    for (const item of mediaItems) {
      const key = `${message.id}:${item.url}`;
      if (!options.manual && this.seenKeys.has(key)) continue;
      this.seenKeys.add(key);

      await this.downloadMedia(message, item, options).catch(err => {
        console.error("[SelectiveMediaSaver] Download failed:", item.url, err);
        BdApi.UI.showToast("SelectiveMediaSaver: download failed. Check console.", { type: "error" });
      });
    }
  }

  isMessageAllowed(message) {
    const userId = String(message.author?.id || "");
    const guildId = String(message.guild_id || "");
    const channelId = String(message.channel_id || "");

    const allowedUsers = new Set((this.settings.allowedUserIds || []).map(String));
    const allowedGuilds = new Set((this.settings.allowedGuildIds || []).map(String));
    const allowedChannels = new Set((this.settings.allowedChannelIds || []).map(String));

    const hasAnyAllowlist = allowedUsers.size > 0 || allowedGuilds.size > 0 || allowedChannels.size > 0;

    if (!this.settings.onlySaveAllowlisted) return true;
    if (!hasAnyAllowlist) return false;

    const userMatch = userId && allowedUsers.has(userId);
    const guildMatch = guildId && allowedGuilds.has(guildId);
    const channelMatch = channelId && allowedChannels.has(channelId);

    if (this.settings.matchAnyAllowlist) return Boolean(userMatch || guildMatch || channelMatch);

    if (allowedUsers.size && !userMatch) return false;
    if (allowedGuilds.size && !guildMatch) return false;
    if (allowedChannels.size && !channelMatch) return false;
    return true;
  }

  extractMedia(message) {
    const found = [];

    const addMedia = (url, source, extra = {}) => {
      if (!url || typeof url !== "string") return;

      const cleanUrl = url.split("?")[0].toLowerCase();
      const ext = this.getExtension(cleanUrl, extra.filename, extra.contentType);

      const isImage = this.mediaExtensions.images.includes(ext) || /^image\//i.test(extra.contentType || "");
      const isVideo = this.mediaExtensions.videos.includes(ext) || /^video\//i.test(extra.contentType || "");

      if (isImage && !this.settings.saveImages) return;
      if (isVideo && !this.settings.saveVideos) return;
      if (!isImage && !isVideo) return;

      const finalExt = ext || (isImage ? ".jpg" : ".mp4");
      if (found.some(item => item.url === url)) return;

      found.push({
        source,
        url,
        kind: isImage ? "image" : "video",
        ext: finalExt,
        filename: extra.filename || null,
        contentType: extra.contentType || null,
        width: extra.width || null,
        height: extra.height || null,
        size: extra.size || null
      });
    };

    const attachments = Array.isArray(message.attachments)
      ? message.attachments
      : message.attachments?.toArray?.() || [];

    for (const attachment of attachments) {
      addMedia(attachment.url || attachment.proxy_url || attachment.proxyUrl, "attachment", {
        filename: attachment.filename || null,
        contentType: attachment.content_type || attachment.contentType || null,
        width: attachment.width || null,
        height: attachment.height || null,
        size: attachment.size || null
      });
    }

    const embeds = Array.isArray(message.embeds)
      ? message.embeds
      : message.embeds?.toArray?.() || [];

    for (const embed of embeds) {
      addMedia(embed.image?.url || embed.image?.proxy_url || embed.image?.proxyUrl, "embed_image", {
        contentType: embed.image?.content_type || embed.image?.contentType || null,
        width: embed.image?.width || null,
        height: embed.image?.height || null
      });

      addMedia(embed.thumbnail?.url || embed.thumbnail?.proxy_url || embed.thumbnail?.proxyUrl, "embed_thumbnail", {
        contentType: embed.thumbnail?.content_type || embed.thumbnail?.contentType || null,
        width: embed.thumbnail?.width || null,
        height: embed.thumbnail?.height || null
      });

      addMedia(embed.video?.url || embed.video?.proxy_url || embed.video?.proxyUrl, "embed_video", {
        contentType: embed.video?.content_type || embed.video?.contentType || null,
        width: embed.video?.width || null,
        height: embed.video?.height || null
      });

      addMedia(embed.url, "embed_url", {
        contentType: embed.content_type || embed.contentType || null
      });
    }

    return found;
  }

  async downloadMedia(message, item, options = {}) {
    const response = await BdApi.Net.fetch(item.url, {
      method: "GET",
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const buffer = Buffer.from(await response.arrayBuffer());
    const fileHash = this.crypto.createHash("sha256").update(buffer).digest("hex");

    if (this.settings.duplicateMode === "skip" && this.hashIndex[fileHash]) {
      this.appendDuplicateMetadata(message, item, this.hashIndex[fileHash], options);
      if (options.manual) BdApi.UI.showToast("Duplicate found; original already saved.", { type: "info" });
      return;
    }

    const folder = this.getSaveFolder(message, item);
    if (!this.fs.existsSync(folder)) this.fs.mkdirSync(folder, { recursive: true });

    const filename = this.buildFilename(message, item, fileHash);
    const outputPath = this.uniquePath(this.path.join(folder, filename));

    this.fs.writeFileSync(outputPath, buffer);
    this.hashIndex[fileHash] = outputPath;
    this.saveJson(this.hashIndexPath, this.hashIndex);

    const metadata = this.buildMetadata(message, item, outputPath, this.path.basename(outputPath), fileHash, false, options);
    if (this.settings.saveMetadata) this.appendMetadata(metadata);

    if (this.settings.showToastOnSave || options.manual) {
      BdApi.UI.showToast(`Saved ${item.kind}: ${this.path.basename(outputPath)}`, {
        type: "success",
        timeout: 2500
      });
    }
  }

  appendDuplicateMetadata(message, item, originalPath, options = {}) {
    const metadata = this.buildMetadata(message, item, originalPath, this.path.basename(originalPath), null, true, options);
    if (this.settings.saveMetadata) this.appendMetadata(metadata);
  }

  buildMetadata(message, item, outputPath, filename, fileHash, duplicate, options = {}) {
    const channel = this.ChannelStore?.getChannel?.(message.channel_id);
    const guild = this.GuildStore?.getGuild?.(message.guild_id);

    return {
      savedAt: new Date().toISOString(),
      manualSave: Boolean(options.manual),
      duplicateReference: Boolean(duplicate),
      file: outputPath,
      filename,
      fileHash,
      kind: item.kind,
      source: item.source,
      url: item.url,
      messageId: message.id,
      channelId: message.channel_id || null,
      channelName: channel?.name || null,
      guildId: message.guild_id || null,
      guildName: guild?.name || null,
      authorId: message.author?.id || null,
      authorTag: this.formatAuthor(message.author),
      messageTimestamp: message.timestamp || null,
      contentType: item.contentType,
      width: item.width,
      height: item.height,
      size: item.size
    };
  }

  getSaveFolder(message, item) {
    if (this.settings.folderMode === "flat") return this.baseDir;
    if (this.settings.folderMode === "kind") return this.path.join(this.baseDir, item.kind === "image" ? "Images" : "Videos");

    const authorName = this.sanitize(this.formatAuthor(message.author) || message.author?.id || "UnknownUser");
    const channel = this.ChannelStore?.getChannel?.(message.channel_id);
    const guild = this.GuildStore?.getGuild?.(message.guild_id);
    const kindFolder = item.kind === "image" ? "Images" : "Videos";

    if (!message.guild_id) return this.path.join(this.baseDir, "DMs", authorName, kindFolder);

    const guildName = this.sanitize(guild?.name || message.guild_id || "UnknownServer");
    const channelName = this.sanitize(channel?.name ? `#${channel.name}` : message.channel_id || "UnknownChannel");
    return this.path.join(this.baseDir, "Servers", guildName, channelName, kindFolder);
  }

  buildFilename(message, item, fileHash) {
    const date = new Date(message.timestamp || Date.now());
    const stamp = date.toISOString().replace("T", " ").replace(/\.\d+Z$/, "").replace(/:/g, "-");

    const author = this.sanitize(
      message.author?.username ||
      message.author?.globalName ||
      message.author?.global_name ||
      message.author?.id ||
      "unknown"
    );

    const base = item.filename ? this.sanitize(this.path.parse(item.filename).name) : item.kind;
    return `${author} - ${stamp} - ${base} - ${fileHash.slice(0, 8)}${item.ext}`;
  }

  uniquePath(filePath) {
    if (!this.fs.existsSync(filePath)) return filePath;

    const parsed = this.path.parse(filePath);
    let i = 2;

    while (true) {
      const candidate = this.path.join(parsed.dir, `${parsed.name} (${i})${parsed.ext}`);
      if (!this.fs.existsSync(candidate)) return candidate;
      i++;
    }
  }

  patchUserUpdateListener() {
    const dispatcher = this.dispatcher;
    if (!dispatcher?.subscribe || !dispatcher?.unsubscribe) return;

    const onUserUpdate = event => {
      try {
        const user = event?.user || event?.users?.[0] || event?.updatedUser || event?.currentUser || null;
        if (!user?.id) return;
        if (!this.settings.trackAvatarChanges) return;
        if (!this.isAllowedId("allowedUserIds", user.id)) return;

        this.checkAndSaveAvatar(user, "USER_UPDATE").catch(err => {
          console.warn("[SelectiveMediaSaver] USER_UPDATE avatar check failed:", err);
        });
      } catch (err) {
        console.warn("[SelectiveMediaSaver] USER_UPDATE handler failed:", err);
      }
    };

    try {
      dispatcher.subscribe("USER_UPDATE", onUserUpdate);
      this.unsubscribeUserUpdate = () => dispatcher.unsubscribe("USER_UPDATE", onUserUpdate);
      this.debug("Subscribed to USER_UPDATE.");
    } catch {}
  }

  startAvatarWatcher() {
    if (this.avatarWatcherInterval) clearInterval(this.avatarWatcherInterval);

    const run = () => {
      if (!this.settings.trackAvatarChanges || !this.settings.saveAvatarsForAllowlistedUsers) return;

      const ids = (this.settings.allowedUserIds || []).map(String).filter(Boolean);
      for (const id of ids) {
        const user = this.UserStore?.getUser?.(id);
        if (!user?.id) continue;
        this.checkAndSaveAvatar(user, "interval").catch(err => console.warn("[SelectiveMediaSaver] Avatar watcher failed:", err));
      }
    };

    run();

    const minutes = Math.max(1, Number(this.settings.avatarCheckIntervalMinutes || 10));
    this.avatarWatcherInterval = setInterval(run, minutes * 60 * 1000);
  }

  getAvatarKey(user) {
    if (!user?.id) return null;
    const avatarId = user.avatar || "";
    const globalName = user.globalName || user.global_name || "";
    return `${user.id}:${avatarId}:${globalName}`;
  }

  async checkAndSaveAvatar(user, reason = "unknown") {
    if (!user?.id) return;
    if (!this.settings.saveAvatarsForAllowlistedUsers) return;
    if (!this.settings.trackAvatarChanges) return;
    if (!this.isAllowedId("allowedUserIds", user.id)) return;

    const key = this.getAvatarKey(user);
    if (!key) return;

    this.settings.avatarHistory = this.settings.avatarHistory || {};
    if (this.settings.avatarHistory[user.id] === key) return;

    const saved = await this.saveAvatar(user, { reason });
    if (saved) {
      this.settings.avatarHistory[user.id] = key;
      this.saveSettings();
    }
  }

  async saveAvatar(user, options = {}) {
    if (!user?.id) return false;

    const avatarUrl = user.getAvatarURL?.(undefined, 512, true) ||
      (user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${String(user.avatar).startsWith("a_") ? "gif" : "png"}?size=512` : null);

    if (!avatarUrl) return false;

    const safeName = this.sanitize(this.formatAuthor(user) || user.id);
    const folder = this.path.join(this.avatarsDir, safeName);
    if (!this.fs.existsSync(folder)) this.fs.mkdirSync(folder, { recursive: true });

    const ext = avatarUrl.includes(".gif") || String(user.avatar || "").startsWith("a_") ? ".gif" : ".png";
    const avatarId = user.avatar || "default";
    const date = new Date().toISOString().replace("T", " ").replace(/\.\d+Z$/, "").replace(/:/g, "-");
    const out = this.uniquePath(this.path.join(folder, `${safeName} - ${date} - ${avatarId}${ext}`));

    const res = await BdApi.Net.fetch(avatarUrl);
    if (!res.ok) return false;

    const buffer = Buffer.from(await res.arrayBuffer());
    this.fs.writeFileSync(out, buffer);

    if (this.settings.saveMetadata) {
      this.appendMetadata({
        savedAt: new Date().toISOString(),
        kind: "avatar",
        avatarChangeReason: options.reason || "unknown",
        file: out,
        filename: this.path.basename(out),
        userId: user.id,
        authorId: user.id,
        authorTag: this.formatAuthor(user),
        avatarId,
        url: avatarUrl
      });
    }

    return true;
  }

  patchUserProfileListener() {
    const dispatcher = this.dispatcher;
    if (!dispatcher?.subscribe || !dispatcher?.unsubscribe) return;

    const onProfile = event => {
      try {
        if (!this.settings.trackBannerChanges) return;

        const profile = event?.userProfile || event?.profile || event?.user_profile || event?.profileUser || event?.user || event?.payload || null;
        const user = profile?.user || event?.user || profile;
        const userId = String(user?.id || profile?.userId || profile?.user_id || event?.userId || event?.user_id || "");
        if (!userId) return;
        if (!this.isAllowedId("allowedUserIds", userId)) return;

        this.checkAndSaveBannerFromProfile(profile, user, "profile-event").catch(err => {
          console.warn("[SelectiveMediaSaver] Profile banner check failed:", err);
        });
      } catch (err) {
        console.warn("[SelectiveMediaSaver] USER_PROFILE handler failed:", err);
      }
    };

    const names = ["USER_PROFILE_FETCH_SUCCESS", "USER_PROFILE_FETCH_COMPLETED", "USER_PROFILE_UPDATE", "USER_PROFILE_FETCH", "USER_PROFILE_MODAL_FETCH_SUCCESS"];
    const unsubs = [];

    for (const name of names) {
      try {
        dispatcher.subscribe(name, onProfile);
        unsubs.push(() => dispatcher.unsubscribe(name, onProfile));
      } catch {}
    }

    this.unsubscribeUserProfileFetch = () => unsubs.forEach(fn => { try { fn(); } catch {} });
  }

  startBannerWatcher() {
    if (this.bannerWatcherInterval) clearInterval(this.bannerWatcherInterval);

    const run = () => {
      if (!this.settings.trackBannerChanges || !this.settings.saveBannersForAllowlistedUsers) return;

      const ids = (this.settings.allowedUserIds || []).map(String).filter(Boolean);
      for (const id of ids) {
        const user = this.UserStore?.getUser?.(id) || { id };
        const profile = this.getCachedProfile(id);
        if (!profile) continue;
        this.checkAndSaveBannerFromProfile(profile, user, "interval").catch(err => console.warn("[SelectiveMediaSaver] Banner watcher failed:", err));
      }
    };

    run();

    const minutes = Math.max(1, Number(this.settings.bannerCheckIntervalMinutes || 15));
    this.bannerWatcherInterval = setInterval(run, minutes * 60 * 1000);
  }

  getCachedProfile(userId) {
    userId = String(userId);
    const mods = [
      this.UserProfileStore,
      BdApi.Webpack.getByKeys("getUserProfile"),
      BdApi.Webpack.getByKeys("getMutableUserProfile"),
      BdApi.Webpack.getByKeys("getProfile")
    ].filter(Boolean);

    const calls = [
      mod => mod?.getUserProfile?.(userId),
      mod => mod?.getMutableUserProfile?.(userId),
      mod => mod?.getProfile?.(userId),
      mod => mod?._profiles?.[userId],
      mod => mod?.profiles?.[userId],
      mod => mod?.userProfiles?.[userId],
      mod => mod?._userProfiles?.[userId]
    ];

    for (const mod of mods) {
      for (const call of calls) {
        try {
          const profile = call(mod);
          if (profile) return profile;
        } catch {}
      }
    }

    return null;
  }

  async checkAllowlistedBannersNow(reason = "manual") {
    const ids = (this.settings.allowedUserIds || []).map(String).filter(Boolean);
    if (!ids.length) {
      BdApi.UI.showToast("No allowlisted user IDs to check.", { type: "info" });
      return;
    }

    let checked = 0;
    let saved = 0;
    let missing = 0;

    for (const id of ids) {
      const user = this.UserStore?.getUser?.(id) || { id };
      const profile = this.getCachedProfile(id);

      if (!profile) {
        missing++;
        continue;
      }

      checked++;
      const before = JSON.stringify(this.settings.bannerHistory || {});
      await this.checkAndSaveBannerFromProfile(profile, user, reason);
      const after = JSON.stringify(this.settings.bannerHistory || {});
      if (before !== after) saved++;
    }

    BdApi.UI.showToast(`Banner check done. Profiles: ${checked}, saved/updated: ${saved}, missing cache: ${missing}.`, {
      type: saved ? "success" : "info",
      timeout: 5000
    });
  }

  getBannerId(profile) {
    if (!profile) return "";

    const candidates = [
      profile.banner,
      profile.bannerHash,
      profile.banner_hash,
      profile.user?.banner,
      profile.user?.bannerHash,
      profile.user?.banner_hash,
      profile.profile?.banner,
      profile.profile?.bannerHash,
      profile.profile?.banner_hash,
      profile.userProfile?.banner,
      profile.userProfile?.bannerHash,
      profile.userProfile?.banner_hash
    ];

    for (const value of candidates) {
      if (typeof value === "string" && value) return value;
    }

    return "";
  }

  getBannerUrl(profile, user) {
    const direct = [profile?.bannerUrl, profile?.bannerURL, profile?.banner_url, profile?.user?.bannerUrl, profile?.user?.bannerURL, profile?.user?.banner_url];
    for (const value of direct) {
      if (typeof value === "string" && value.startsWith("http")) return value;
    }

    const userId = String(user?.id || profile?.userId || profile?.user_id || profile?.user?.id || profile?.profile?.userId || "");
    const bannerId = this.getBannerId(profile);

    if (!userId || !bannerId) {
      this.debug("No banner URL could be built.", { userId, bannerId, profile });
      return null;
    }

    const ext = String(bannerId).startsWith("a_") ? "gif" : "png";
    return `https://cdn.discordapp.com/banners/${userId}/${bannerId}.${ext}?size=1024`;
  }

  getBannerKey(profile, user) {
    const userId = String(user?.id || profile?.userId || profile?.user_id || profile?.user?.id || "");
    const bannerId = this.getBannerId(profile);
    if (!userId || !bannerId) return null;
    return `${userId}:${bannerId}`;
  }

  async checkAndSaveBannerFromProfile(profile, user, reason = "unknown") {
    if (!this.settings.saveBannersForAllowlistedUsers) return;
    if (!this.settings.trackBannerChanges) return;

    const userId = String(user?.id || profile?.userId || profile?.user_id || profile?.user?.id || "");
    if (!userId) return;
    if (!this.isAllowedId("allowedUserIds", userId)) return;

    const key = this.getBannerKey(profile, user);
    if (!key) return;

    this.settings.bannerHistory = this.settings.bannerHistory || {};
    if (this.settings.bannerHistory[userId] === key) return;

    const saved = await this.saveBanner(profile, user, { reason });
    if (saved) {
      this.settings.bannerHistory[userId] = key;
      this.saveSettings();
    }
  }

  async saveBanner(profile, user, options = {}) {
    const userId = String(user?.id || profile?.userId || profile?.user_id || profile?.user?.id || "");
    if (!userId) return false;

    const bannerUrl = this.getBannerUrl(profile, user);
    if (!bannerUrl) return false;

    const safeName = this.sanitize(this.formatAuthor(user) || profile?.user?.username || userId);
    const folder = this.path.join(this.bannersDir, safeName);
    if (!this.fs.existsSync(folder)) this.fs.mkdirSync(folder, { recursive: true });

    const bannerId = this.getBannerId(profile);
    const ext = String(bannerId).startsWith("a_") ? ".gif" : ".png";
    const date = new Date().toISOString().replace("T", " ").replace(/\.\d+Z$/, "").replace(/:/g, "-");
    const out = this.uniquePath(this.path.join(folder, `${safeName} - ${date} - ${bannerId}${ext}`));

    const res = await BdApi.Net.fetch(bannerUrl);
    if (!res.ok) return false;

    const buffer = Buffer.from(await res.arrayBuffer());
    this.fs.writeFileSync(out, buffer);

    if (this.settings.saveMetadata) {
      this.appendMetadata({
        savedAt: new Date().toISOString(),
        kind: "banner",
        bannerChangeReason: options.reason || "profile",
        file: out,
        filename: this.path.basename(out),
        userId,
        authorId: userId,
        authorTag: this.formatAuthor(user) || profile?.user?.username || null,
        bannerId,
        url: bannerUrl
      });
    }

    if (this.settings.showToastOnSave) {
      BdApi.UI.showToast(`Saved banner: ${safeName}`, { type: "success", timeout: 2500 });
    }

    return true;
  }

  patchContextMenus() {
    this.contextMenuUnpatches = [];
    if (!BdApi.ContextMenu?.patch || !BdApi.ContextMenu?.buildItem) return;

    const patch = (name, callback) => {
      try {
        const unpatch = BdApi.ContextMenu.patch(name, callback);
        if (typeof unpatch === "function") this.contextMenuUnpatches.push(unpatch);
      } catch {}
    };

    const menus = ["user-context", "user-profile-actions", "user-profile-overflow-menu", "message", "message-actions", "channel-context", "thread-context", "guild-context", "guild-header-popout", "dm-context", "gdm-context"];
    for (const menu of menus) patch(menu, (ret, props) => this.addContextMenuItems(ret, props));
  }

  addContextMenuItems(ret, props) {
    const items = [];

    const userId = props?.user?.id || props?.message?.author?.id || props?.profile?.user?.id;
    const channelId = props?.channel?.id || props?.message?.channel_id;
    const guildId = props?.guild?.id || props?.message?.guild_id || props?.channel?.guild_id;

    if (props?.message) {
      items.push(this.buildContextItem(`sms-save-message-${props.message.id}`, "SelectiveMediaSaver: save media from this message", () => this.handleMessage(props.message, { manual: true })));
    }

    if (userId) {
      const enabled = this.isAllowedId("allowedUserIds", userId);
      items.push(this.buildContextItem(`sms-toggle-user-${userId}`, `${enabled ? "✓ " : ""}SelectiveMediaSaver: ${enabled ? "stop user" : "save user"}`, () => this.toggleAllowId("allowedUserIds", userId, `user ${userId}`)));
    }

    if (channelId) {
      const enabled = this.isAllowedId("allowedChannelIds", channelId);
      items.push(this.buildContextItem(`sms-toggle-channel-${channelId}`, `${enabled ? "✓ " : ""}SelectiveMediaSaver: ${enabled ? "stop channel" : "save channel"}`, () => this.toggleAllowId("allowedChannelIds", channelId, `channel ${channelId}`)));
    }

    if (guildId) {
      const enabled = this.isAllowedId("allowedGuildIds", guildId);
      items.push(this.buildContextItem(`sms-toggle-guild-${guildId}`, `${enabled ? "✓ " : ""}SelectiveMediaSaver: ${enabled ? "stop server" : "save server"}`, () => this.toggleAllowId("allowedGuildIds", guildId, `server ${guildId}`)));
    }

    if (!items.length) return;
    this.pushContextItems(ret, items);
  }

  buildContextItem(id, label, action) {
    return BdApi.ContextMenu.buildItem({ type: "button", id, label, action });
  }

  pushContextItems(ret, items) {
    const separator = BdApi.ContextMenu.buildItem({ type: "separator" });
    const allItems = [separator, ...items];

    const tryPush = children => {
      if (!children) return false;
      if (Array.isArray(children)) {
        children.push(...allItems);
        return true;
      }
      if (Array.isArray(children.props?.children)) {
        children.props.children.push(...allItems);
        return true;
      }
      return false;
    };

    if (tryPush(ret?.props?.children)) return;
    if (tryPush(ret?.props?.children?.props?.children)) return;
    if (tryPush(ret?.props?.items)) return;

    if (ret?.props) {
      ret.props.children = Array.isArray(ret.props.children)
        ? [...ret.props.children, ...allItems]
        : [ret.props.children, ...allItems].filter(Boolean);
    }
  }

  isAllowedId(settingKey, id) {
    return (this.settings[settingKey] || []).map(String).includes(String(id));
  }

  toggleAllowId(settingKey, id, label) {
    id = String(id);
    const list = Array.isArray(this.settings[settingKey]) ? [...this.settings[settingKey]].map(String) : [];
    const index = list.indexOf(id);
    const adding = index === -1;

    if (adding) list.push(id);
    else list.splice(index, 1);

    this.settings[settingKey] = list;
    this.saveSettings();

    BdApi.UI.showToast(adding ? `Now saving media from ${label}.` : `Stopped saving media from ${label}.`, {
      type: adding ? "success" : "info"
    });
  }

  appendMetadata(entry) {
    this.metadataCache = Array.isArray(this.metadataCache) ? this.metadataCache : [];
    this.metadataCache.push(entry);
    this.saveJson(this.metadataPath, this.metadataCache);
  }

  runCleanupSafe() {
    try {
      if (!this.settings.autoCleanupEnabled) return;
      this.runCleanup();
    } catch (err) {
      console.warn("[SelectiveMediaSaver] Cleanup failed:", err);
    }
  }

  runCleanup() {
    const files = this.listFilesRecursive(this.baseDir)
      .filter(file => !file.endsWith("metadata.json") && !file.endsWith("hash_index.json"))
      .map(file => {
        const st = this.fs.statSync(file);
        return { file, size: st.size, mtime: st.mtimeMs };
      })
      .sort((a, b) => a.mtime - b.mtime);

    const olderThanDays = Number(this.settings.deleteOlderThanDays || 0);
    if (olderThanDays > 0) {
      const cutoff = Date.now() - olderThanDays * 24 * 60 * 60 * 1000;
      for (const f of files.filter(x => x.mtime < cutoff)) {
        try { this.fs.unlinkSync(f.file); } catch {}
      }
    }

    const maxBytes = Number(this.settings.maxTotalSizeGB || 0) * 1024 * 1024 * 1024;
    if (maxBytes > 0) {
      const refreshed = this.listFilesRecursive(this.baseDir)
        .filter(file => !file.endsWith("metadata.json") && !file.endsWith("hash_index.json"))
        .map(file => {
          const st = this.fs.statSync(file);
          return { file, size: st.size, mtime: st.mtimeMs };
        })
        .sort((a, b) => a.mtime - b.mtime);

      let total = refreshed.reduce((sum, f) => sum + f.size, 0);
      for (const f of refreshed) {
        if (total <= maxBytes) break;
        try {
          this.fs.unlinkSync(f.file);
          total -= f.size;
        } catch {}
      }
    }
  }

  listFilesRecursive(dir) {
    if (!this.fs.existsSync(dir)) return [];
    const result = [];
    const stack = [dir];

    while (stack.length) {
      const current = stack.pop();
      for (const name of this.fs.readdirSync(current)) {
        const p = this.path.join(current, name);
        const st = this.fs.statSync(p);
        if (st.isDirectory()) stack.push(p);
        else result.push(p);
      }
    }

    return result;
  }

  getExtension(cleanUrl, filename, contentType) {
    const fromFilename = filename ? this.path.extname(filename).toLowerCase() : "";
    if (fromFilename) return fromFilename;

    try {
      const ext = this.path.extname(new URL(cleanUrl).pathname).toLowerCase();
      if (ext) return ext;
    } catch {
      const ext = this.path.extname(cleanUrl).toLowerCase();
      if (ext) return ext;
    }

    const ct = String(contentType || "").toLowerCase();
    if (ct.includes("png")) return ".png";
    if (ct.includes("jpeg") || ct.includes("jpg")) return ".jpg";
    if (ct.includes("gif")) return ".gif";
    if (ct.includes("webp")) return ".webp";
    if (ct.includes("mp4")) return ".mp4";
    if (ct.includes("webm")) return ".webm";
    if (ct.includes("quicktime")) return ".mov";
    return "";
  }

  sanitize(value) {
    return String(value)
      .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
      .replace(/\s+/g, "_")
      .slice(0, 80);
  }

  formatAuthor(author) {
    if (!author) return null;
    const username = author.username || author.globalName || author.global_name || "Unknown";
    const discriminator = author.discriminator && author.discriminator !== "0" ? `#${author.discriminator}` : "";
    return `${username}${discriminator}`;
  }

  parseIdList(value) {
    return String(value || "").split(/[\s,]+/g).map(x => x.trim()).filter(Boolean);
  }

  makeTextarea(labelText, noteText, settingKey) {
    const wrapper = document.createElement("div");
    wrapper.style.margin = "16px 0";

    const label = document.createElement("div");
    label.textContent = labelText;
    label.style.fontWeight = "600";
    label.style.marginBottom = "4px";
    wrapper.appendChild(label);

    const note = document.createElement("div");
    note.textContent = noteText;
    note.style.opacity = "0.75";
    note.style.fontSize = "12px";
    note.style.marginBottom = "8px";
    wrapper.appendChild(note);

    const textarea = document.createElement("textarea");
    textarea.value = (this.settings[settingKey] || []).join("\n");
    textarea.placeholder = "One ID per line, or comma-separated";
    textarea.style.width = "100%";
    textarea.style.minHeight = "90px";
    textarea.style.boxSizing = "border-box";
    textarea.style.resize = "vertical";

    textarea.addEventListener("change", () => {
      this.settings[settingKey] = this.parseIdList(textarea.value);
      this.saveSettings();
      BdApi.UI.showToast("SelectiveMediaSaver settings saved.", { type: "success" });
    });

    wrapper.appendChild(textarea);
    return wrapper;
  }

  makeCheckbox(labelText, settingKey) {
    const wrapper = document.createElement("label");
    wrapper.style.display = "flex";
    wrapper.style.alignItems = "center";
    wrapper.style.gap = "8px";
    wrapper.style.margin = "10px 0";

    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(this.settings[settingKey]);

    input.addEventListener("change", () => {
      this.settings[settingKey] = input.checked;
      this.saveSettings();
      BdApi.UI.showToast("SelectiveMediaSaver settings saved.", { type: "success" });
    });

    const text = document.createElement("span");
    text.textContent = labelText;
    wrapper.appendChild(input);
    wrapper.appendChild(text);
    return wrapper;
  }

  makeInput(labelText, settingKey, type = "number") {
    const wrapper = document.createElement("div");
    wrapper.style.margin = "10px 0";

    const label = document.createElement("label");
    label.textContent = labelText;
    label.style.display = "block";
    label.style.fontWeight = "600";
    label.style.marginBottom = "4px";

    const input = document.createElement("input");
    input.type = type;
    input.value = this.settings[settingKey];
    input.style.width = "160px";

    input.addEventListener("change", () => {
      const n = Number(input.value);
      this.settings[settingKey] = Number.isFinite(n) ? n : this.defaultSettings[settingKey];
      this.saveSettings();
    });

    wrapper.appendChild(label);
    wrapper.appendChild(input);
    return wrapper;
  }

  makeSelect(labelText, settingKey, options) {
    const wrapper = document.createElement("div");
    wrapper.style.margin = "10px 0";

    const label = document.createElement("label");
    label.textContent = labelText;
    label.style.display = "block";
    label.style.fontWeight = "600";
    label.style.marginBottom = "4px";

    const select = document.createElement("select");
    for (const [value, text] of options) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = text;
      opt.selected = this.settings[settingKey] === value;
      select.appendChild(opt);
    }

    select.addEventListener("change", () => {
      this.settings[settingKey] = select.value;
      this.saveSettings();
      BdApi.UI.showToast("SelectiveMediaSaver settings saved.", { type: "success" });
    });

    wrapper.appendChild(label);
    wrapper.appendChild(select);
    return wrapper;
  }

  makeButton(text, onclick) {
    const button = document.createElement("button");
    button.textContent = text;
    button.style.padding = "8px 12px";
    button.style.marginRight = "8px";
    button.style.marginBottom = "8px";
    button.onclick = onclick;
    return button;
  }

  getCurrentChannelId() {
    return this.SelectedChannelStore?.getChannelId?.() || this.SelectedChannelStore?.getVoiceChannelId?.() || null;
  }

  getCurrentGuildId() {
    return this.SelectedGuildStore?.getGuildId?.() || null;
  }

  getSettingsPanel() {
    const panel = document.createElement("div");
    panel.style.padding = "16px";
    panel.style.maxWidth = "900px";

    const title = document.createElement("h2");
    title.textContent = "SelectiveMediaSaver v2.4";
    panel.appendChild(title);

    const explain = document.createElement("p");
    explain.textContent = "Saves image/video files from selected users, channels, or servers. Banners are saved only after Discord naturally caches/loads the profile.";
    panel.appendChild(explain);

    const buttonRow = document.createElement("div");
    buttonRow.style.margin = "12px 0";

    buttonRow.appendChild(this.makeButton("Add current channel", () => {
      const id = this.getCurrentChannelId();
      if (!id) return BdApi.UI.showToast("No current channel found.", { type: "error" });
      this.settings.allowedChannelIds = this.settings.allowedChannelIds || [];
      if (!this.isAllowedId("allowedChannelIds", id)) this.settings.allowedChannelIds.push(String(id));
      this.saveSettings();
      BdApi.UI.showToast("Current channel added.", { type: "success" });
    }));

    buttonRow.appendChild(this.makeButton("Add current server", () => {
      const id = this.getCurrentGuildId();
      if (!id) return BdApi.UI.showToast("No current server found.", { type: "error" });
      this.settings.allowedGuildIds = this.settings.allowedGuildIds || [];
      if (!this.isAllowedId("allowedGuildIds", id)) this.settings.allowedGuildIds.push(String(id));
      this.saveSettings();
      BdApi.UI.showToast("Current server added.", { type: "success" });
    }));

    buttonRow.appendChild(this.makeButton("Open save folder", () => {
      try { require("electron").shell.openPath(this.baseDir); }
      catch { BdApi.UI.showToast("Could not open save folder.", { type: "error" }); }
    }));

    buttonRow.appendChild(this.makeButton("Run cleanup now", () => {
      this.runCleanupSafe();
      BdApi.UI.showToast("Cleanup finished.", { type: "success" });
    }));

    buttonRow.appendChild(this.makeButton("Check banners now", () => {
      this.checkAllowlistedBannersNow("settings-button").catch(err => {
        console.error("[SelectiveMediaSaver] Manual banner check failed:", err);
        BdApi.UI.showToast("Banner check failed. Check console.", { type: "error" });
      });
    }));

    panel.appendChild(buttonRow);

    panel.appendChild(this.makeCheckbox("Plugin enabled", "enabled"));
    panel.appendChild(this.makeCheckbox("Only save allowlisted users/servers/channels", "onlySaveAllowlisted"));
    panel.appendChild(this.makeCheckbox("Match any allowlist entry instead of requiring all filled categories to match", "matchAnyAllowlist"));
    panel.appendChild(this.makeCheckbox("Ignore bots", "ignoreBots"));
    panel.appendChild(this.makeCheckbox("Ignore my own messages", "ignoreSelf"));
    panel.appendChild(this.makeCheckbox("Save images", "saveImages"));
    panel.appendChild(this.makeCheckbox("Save videos", "saveVideos"));
    panel.appendChild(this.makeCheckbox("Save avatars for allowlisted users", "saveAvatarsForAllowlistedUsers"));
    panel.appendChild(this.makeCheckbox("Save banners for allowlisted users", "saveBannersForAllowlistedUsers"));
    panel.appendChild(this.makeCheckbox("Track avatar changes without waiting for a DM/media message", "trackAvatarChanges"));
    panel.appendChild(this.makeCheckbox("Track banner changes when profiles are cached/fetched", "trackBannerChanges"));
    panel.appendChild(this.makeInput("Avatar check interval in minutes", "avatarCheckIntervalMinutes"));
    panel.appendChild(this.makeInput("Banner check interval in minutes", "bannerCheckIntervalMinutes"));
    panel.appendChild(this.makeCheckbox("Show toast when media is saved", "showToastOnSave"));
    panel.appendChild(this.makeCheckbox("Save metadata.json", "saveMetadata"));
    panel.appendChild(this.makeCheckbox("Debug logs in DevTools console", "debugMode"));
    panel.appendChild(this.makeCheckbox("Try right-click context menu toggles", "contextMenuToggles"));

    panel.appendChild(this.makeSelect("Folder organization", "folderMode", [
      ["smart", "Smart: Servers/Server/Channel and DMs/User"],
      ["kind", "Simple: Images and Videos"],
      ["flat", "Flat: everything in main folder"]
    ]));

    panel.appendChild(this.makeSelect("Duplicate handling", "duplicateMode", [
      ["skip", "Skip duplicate files"],
      ["save", "Save duplicates anyway"]
    ]));

    panel.appendChild(this.makeCheckbox("Auto-cleanup enabled", "autoCleanupEnabled"));
    panel.appendChild(this.makeInput("Max total size in GB", "maxTotalSizeGB"));
    panel.appendChild(this.makeInput("Delete files older than X days; 0 disables age cleanup", "deleteOlderThanDays"));

    panel.appendChild(this.makeTextarea("Allowed user IDs", "Media/avatar/banner from these users will be saved when available.", "allowedUserIds"));
    panel.appendChild(this.makeTextarea("Allowed server IDs", "Media from any channel inside these servers will be saved.", "allowedGuildIds"));
    panel.appendChild(this.makeTextarea("Allowed channel IDs", "Media from these exact channels or DMs will be saved.", "allowedChannelIds"));

    const browserTitle = document.createElement("h3");
    browserTitle.textContent = "Recent saved media";
    panel.appendChild(browserTitle);

    const browser = document.createElement("div");
    browser.style.maxHeight = "320px";
    browser.style.overflow = "auto";
    browser.style.border = "1px solid var(--background-modifier-accent)";
    browser.style.padding = "8px";
    browser.style.borderRadius = "6px";

    const recent = (Array.isArray(this.metadataCache) ? this.metadataCache : []).slice(-40).reverse();

    if (!recent.length) {
      browser.textContent = "No saved media yet.";
    } else {
      for (const item of recent) {
        const row = document.createElement("div");
        row.style.display = "flex";
        row.style.alignItems = "center";
        row.style.gap = "8px";
        row.style.padding = "6px 0";
        row.style.borderBottom = "1px solid var(--background-modifier-accent)";

        if ((item.kind === "image" || item.kind === "avatar" || item.kind === "banner") && item.file && this.fs.existsSync(item.file)) {
          const img = document.createElement("img");
          img.src = `file://${item.file}`;
          img.style.width = "54px";
          img.style.height = "54px";
          img.style.objectFit = "cover";
          img.style.borderRadius = "4px";
          row.appendChild(img);
        } else {
          const badge = document.createElement("div");
          badge.textContent = String(item.kind || "FILE").toUpperCase();
          badge.style.width = "54px";
          badge.style.textAlign = "center";
          badge.style.fontSize = "11px";
          row.appendChild(badge);
        }

        const text = document.createElement("div");
        text.style.flex = "1";
        text.style.fontSize = "12px";
        text.textContent = `${item.authorTag || "Unknown"} • ${item.guildName || "DM"} ${item.channelName ? "• " + item.channelName : ""} • ${item.filename || item.kind}`;
        row.appendChild(text);

        const open = this.makeButton("Open", () => {
          try { require("electron").shell.openPath(item.file); } catch {}
        });
        row.appendChild(open);

        browser.appendChild(row);
      }
    }

    panel.appendChild(browser);

    const pathInfo = document.createElement("p");
    pathInfo.textContent = `Saving files to: ${this.baseDir}`;
    panel.appendChild(pathInfo);

    return panel;
  }
};
